package com.capgemini.bank.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.TransactionIdNotValidatedException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;

public class DemandDraftDAO implements IDemandDraftDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	private static final Logger logger=Logger.getLogger(DemandDraftService.class);
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, BankingServicesDownException{
		int transactionId=0;
		try{
			if(conn==null)
				throw new BankingServicesDownException();
				conn.setAutoCommit(false);
				PreparedStatement pstmt1=conn.prepareStatement("insert into demand_draft(customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description) values(?,?,?,?,?,?,?)");
				pstmt1.setString(1,demandDraft.getCustomerName());
				pstmt1.setString(2, demandDraft.getInFavorOf());
				pstmt1.setLong(3, demandDraft.getMobileNo());
				pstmt1.setString(4,"18/5/11");
				pstmt1.setDouble(5, demandDraft.getDdAmount());
				pstmt1.setDouble(6,demandDraft.getDdCommission());
				pstmt1.setString(7,demandDraft.getDdDescription());
				pstmt1.executeUpdate();

				PreparedStatement pstmt2=conn.prepareStatement("select Max(transaction_id) from demand_draft");
				ResultSet RS=pstmt2.executeQuery();
				RS.next();
				transactionId=RS.getInt(1);
				conn.commit();
				demandDraft.setTransactionId(transactionId);
		}catch(SQLException e){
			logger.error(e.getMessage()+"= "+e.getCause()+"= "+e.getErrorCode()+"= ");
			conn.rollback();
			conn.close();
			e.printStackTrace();
		}
		finally{
			conn.setAutoCommit(true);		
		}
		return transactionId;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws TransactionIdNotValidatedException, BankingServicesDownException {
		if(conn==null)
			throw new BankingServicesDownException();
		try{
			PreparedStatement pstmt=conn.prepareStatement("select * from demand_draft where transaction_id="+transactionId);
			ResultSet RS=pstmt.executeQuery();
			if(RS.next()){
				String name=RS.getString("customer_name");
				String inFavorOf=RS.getString("in_favor_of");
				Long mobileNo=RS.getLong("phone_number");
				String date=RS.getString("date_of_transaction");
				double ddAmount=RS.getDouble("dd_amount");
				double ddCommission=RS.getDouble("dd_commission");
				String ddDescription=RS.getString("dd_description");
				DemandDraft demandDraft=new DemandDraft(transactionId,name,inFavorOf,mobileNo,date,ddAmount,ddCommission,ddDescription);
				return demandDraft;
			}
			else
				throw new TransactionIdNotValidatedException();
		}catch(SQLException e){
			logger.error(e.getMessage()+"= "+e.getCause()+"= "+e.getErrorCode()+"= ");
			e.printStackTrace();
		}
		return null;
}
}