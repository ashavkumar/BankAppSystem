package com.capgemini.bank.dao;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.TransactionIdNotValidatedException;
public interface IDemandDraftDAO {
	int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, BankingServicesDownException;
	DemandDraft getDemandDraftDetails(int transactionId) throws TransactionIdNotValidatedException, BankingServicesDownException;
}
