package com.capgemini.bank.exception;
@SuppressWarnings("serial")
public class DdAmountNotValidatedException extends Exception{

}
