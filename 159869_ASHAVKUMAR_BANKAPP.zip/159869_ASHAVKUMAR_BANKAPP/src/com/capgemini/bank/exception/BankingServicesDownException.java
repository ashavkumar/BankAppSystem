package com.capgemini.bank.exception;

public class BankingServicesDownException extends Exception {

}
