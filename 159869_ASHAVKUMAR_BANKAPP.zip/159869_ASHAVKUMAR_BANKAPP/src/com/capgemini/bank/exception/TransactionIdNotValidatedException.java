package com.capgemini.bank.exception;

public class TransactionIdNotValidatedException extends Exception {

}
