package com.capgemini.bank.ui;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.DdAmountNotValidatedException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;

public class Client {
	public static void main(String[] args) throws DdAmountNotValidatedException, SQLException, BankingServicesDownException {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Database Connected");
		else
			System.out.println("Some Problem");
		IDemandDraftService idemanddraftservice=new DemandDraftService();
		DemandDraft demanddraft=new DemandDraft("John",97685873,"capgemini",45000,"DD taken in favor of Capgemini");
		int transactionId=idemanddraftservice.addDemandDraftDetails(demanddraft);
		System.out.println(transactionId);
		
		@SuppressWarnings("resource")
		Scanner scr=new Scanner(System.in);
		String ch=null;
		do{
			System.out.println("1.Enter Demand Draft Details");
			System.out.println("2.Exit");
			System.out.println("Enter Your Choice");
			int choice=scr.nextInt();
			switch(choice){
			case 1:
				System.out.println("Enter your name of the customer");
				String name=scr.next();
				System.out.println("Enter customer phone Number");
				Long mobileNo=scr.nextLong();
				System.out.println("In favor of");
				String inFavorOf=scr.next();
				System.out.print("Enter Demand Draft amount in Rs");
				double ddAmount=scr.nextDouble();
				System.out.println("Enter Remarks");
				String remarks=scr.next();
				DemandDraft demanddraft1=new DemandDraft(name,mobileNo,inFavorOf,ddAmount,remarks);
				int transactionId1=idemanddraftservice.addDemandDraftDetails(demanddraft1);
				System.out.println("Your Demand Draft request has been successfully registered alog with the"+transactionId1);
				break;
			default:
				System.out.println("Enter Valid choice");
			}
			System.out.println("Do you want to continue then press y otherwise n");
			ch=scr.next();
		}while(ch.startsWith("y") || ch.startsWith("Y"));
	}
}
