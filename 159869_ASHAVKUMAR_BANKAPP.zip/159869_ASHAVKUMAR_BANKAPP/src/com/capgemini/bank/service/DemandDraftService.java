package com.capgemini.bank.service;
import java.sql.SQLException;
import java.time.LocalDate;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.DdAmountNotValidatedException;
import com.capgemini.bank.exception.TransactionIdNotValidatedException;
public class DemandDraftService implements IDemandDraftService{
	IDemandDraftDAO demanddraftdao=new DemandDraftDAO();
	private static final Logger logger=Logger.getLogger(DemandDraftService.class);
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws DdAmountNotValidatedException, SQLException, BankingServicesDownException {
	String name=demandDraft.getCustomerName();
	long mobileNO=demandDraft.getMobileNo();
	String inFavorOf=demandDraft.getInFavorOf();
	double ddAmount=demandDraft.getDdAmount();
	String remarks=demandDraft.getDdDescription();
	
	int commision;
	if(ddAmount<=5000)
		commision=10;
	else if(ddAmount>=5001 && ddAmount<=10000)
		commision=41;
	else if(ddAmount>=10001 && ddAmount<=100000)
		commision=51;
	else if(ddAmount>=100001 && ddAmount<=500000)
		commision=306;
	else 
		throw new DdAmountNotValidatedException();
	LocalDate todayDate=LocalDate.now();
	String todayDate1="21/01/2018";
	
	DemandDraft newDemandDraft=new DemandDraft();
	newDemandDraft.setCustomerName(name);
	newDemandDraft.setMobileNo(mobileNO);
	newDemandDraft.setInFavorOf(inFavorOf);
	newDemandDraft.setDdAmount(ddAmount);
	newDemandDraft.setDdDescription(remarks);
	newDemandDraft.setDdCommission(commision);
	newDemandDraft.setDateOfTransaction(todayDate1);
	
	int transactionId=demanddraftdao.addDemandDraftDetails(newDemandDraft);
		return transactionId;
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws TransactionIdNotValidatedException, BankingServicesDownException {
		DemandDraft demandDraft=demanddraftdao.getDemandDraftDetails(transactionId);
		return demandDraft;
	}
}
