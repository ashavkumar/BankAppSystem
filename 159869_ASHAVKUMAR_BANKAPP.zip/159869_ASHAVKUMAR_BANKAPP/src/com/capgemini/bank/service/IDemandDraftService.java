package com.capgemini.bank.service;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankingServicesDownException;
import com.capgemini.bank.exception.DdAmountNotValidatedException;
import com.capgemini.bank.exception.TransactionIdNotValidatedException;
public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft) throws DdAmountNotValidatedException, SQLException, BankingServicesDownException;
	DemandDraft getDemandDraftDetails(int transactionId) throws TransactionIdNotValidatedException, BankingServicesDownException;
}
