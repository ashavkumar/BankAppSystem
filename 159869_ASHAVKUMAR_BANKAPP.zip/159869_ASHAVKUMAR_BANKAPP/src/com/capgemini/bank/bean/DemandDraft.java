package com.capgemini.bank.bean;
import java.time.LocalDate;
public class DemandDraft {
	private int transactionId;
	private String customerName;
	private String inFavorOf;
	private long mobileNo;
	private String dateOfTransaction;
	private double ddAmount;
	private double ddCommission;
	private String ddDescription;
	public DemandDraft() {
		super();
	}
	public DemandDraft(int transactionId, String customerName,
			String inFavorOf, long mobileNo, String dateOfTransaction,
			double ddAmount, double ddCommission, String ddDescription) {
		super();
		this.transactionId = transactionId;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.mobileNo = mobileNo;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDescription = ddDescription;
	}
	public DemandDraft(String string, long i, String string2, double j,
			String string3) {
		
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public double getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(double ddAmount) {
		this.ddAmount = ddAmount;
	}
	public double getDdCommission() {
		return ddCommission;
	}
	public void setDdCommission(double ddCommission) {
		this.ddCommission = ddCommission;
	}
	public String getDdDescription() {
		return ddDescription;
	}
	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime
				* result
				+ ((dateOfTransaction == null) ? 0 : dateOfTransaction
						.hashCode());
		long temp;
		temp = Double.doubleToLongBits(ddAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(ddCommission);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result
				+ ((ddDescription == null) ? 0 : ddDescription.hashCode());
		result = prime * result
				+ ((inFavorOf == null) ? 0 : inFavorOf.hashCode());
		result = prime * result + (int) (mobileNo ^ (mobileNo >>> 32));
		result = prime * result + transactionId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DemandDraft other = (DemandDraft) obj;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (dateOfTransaction == null) {
			if (other.dateOfTransaction != null)
				return false;
		} else if (!dateOfTransaction.equals(other.dateOfTransaction))
			return false;
		if (Double.doubleToLongBits(ddAmount) != Double
				.doubleToLongBits(other.ddAmount))
			return false;
		if (Double.doubleToLongBits(ddCommission) != Double
				.doubleToLongBits(other.ddCommission))
			return false;
		if (ddDescription == null) {
			if (other.ddDescription != null)
				return false;
		} else if (!ddDescription.equals(other.ddDescription))
			return false;
		if (inFavorOf == null) {
			if (other.inFavorOf != null)
				return false;
		} else if (!inFavorOf.equals(other.inFavorOf))
			return false;
		if (mobileNo != other.mobileNo)
			return false;
		if (transactionId != other.transactionId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId
				+ ", customerName=" + customerName + ", inFavorOf=" + inFavorOf
				+ ", mobileNo=" + mobileNo + ", dateOfTransaction="
				+ dateOfTransaction + ", ddAmount=" + ddAmount
				+ ", ddCommission=" + ddCommission + ", ddDescription="
				+ ddDescription + "]";
	}
}
