package com.cg.project.collectiondemoclients;

import com.cg.project.collectiondemo.ListClassesDemo;

public class MainClass {
	

	public static void main(String[] args) {
		ListClassesDemo listdemo=new ListClassesDemo();
		listdemo.arrayListClassWork();
		
		
	}

}
