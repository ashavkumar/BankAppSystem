package com.cg.project.collectiondemoclients;
public class Associate {
	
	private int AssociateId;
	private int Salary;
	private String Name;
	public Associate() {
		super();
	}
	public Associate(int associateId, int salary, String name) {
		super();
		AssociateId = associateId;
		Salary = salary;
		Name = name;
	}
	public int getAssociateId() {
		return AssociateId;
	}
	public void setAssociateId(int associateId) {
		AssociateId = associateId;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + AssociateId;
		result = prime * result + ((Name == null) ? 0 : Name.hashCode());
		result = prime * result + Salary;
		return result;
	}*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (AssociateId != other.AssociateId)
			return false;
		if (Name == null) {
			if (other.Name != null)
				return false;
		} else if (!Name.equals(other.Name))
			return false;
		if (Salary != other.Salary)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Associate [AssociateId=" + AssociateId + ", Salary=" + Salary
				+ ", Name=" + Name + "]";
	}
	public int compareTo(Associate o){
		return this.AssociateId-o.AssociateId;
	}
}
