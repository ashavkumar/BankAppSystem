package com.cg.project.collectiondemo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Vector;
import com.cg.project.collectiondemoclients.Associate;
public class ListClassesDemo {
	public static void  arrayListClassWork() {
		System.out.println("ArrayList Implementation");
		ArrayList<String> strList=new ArrayList<>();
		//ArrayList Insertion
		strList.add("Ashav");
		strList.add("Rakesh");
		strList.add("Mahesh");
		strList.add("Rahul");
		strList.add("Raj");
		//ArrayList Searching
		System.out.println(strList.contains("Mahesh"));
		System.out.println(strList.contains("Raj"));
		//ArrayList Sorting
		Collections.sort(strList);
		//ArrayList Retrieving
		for(String name:strList)
			System.out.println(name);
		//ArrayList Class Type
		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(new Associate(101,15000,"satish"));
		associateList.add(new Associate(102,16582,"Nilesh"));
		associateList.add(new Associate(103,17002,"Mahesh"));
		associateList.add(new Associate(104,19500,"Rakesh"));
		Associate associateToBeSearch = new Associate(102,16582,"Nilesh");
		System.out.println(associateList.indexOf(associateToBeSearch));
		System.out.println(associateList.contains(associateToBeSearch));
		for(Associate associate:associateList)
			System.out.println(associate);
		for(Associate associate:associateList)
			if(associate.getAssociateId()==103&&associate.getName().equals("Nilesh"));
		System.out.println("Data is valid");
		System.out.println("LinkedList Implementation");
		LinkedList<String>linkedlist=new LinkedList<String>();
		linkedlist.add("Ashav");
		linkedlist.add("Rahul");
		linkedlist.add("Mohan");
		linkedlist.add("Suresh");
		linkedlist.add("Rajesh");
		
		System.out.println(linkedlist.contains("Ashav"));
		System.out.println(linkedlist.contains("Suresh"));
		
		Collections.sort(linkedlist);

		for(String Name:linkedlist)
			System.out.println(Name);
		
		LinkedList<Associate>associatelinkedlist=new LinkedList<>();
		associatelinkedlist.add(new Associate(101,15000,"Ashav"));
		associatelinkedlist.add(new Associate(102,16754,"Paresh"));
		
		Associate associatetobesearch=new Associate(102,16754,"Paresh");
		System.out.println(associatelinkedlist.contains(associatetobesearch));
		System.out.println(associatelinkedlist.indexOf(associatetobesearch));
		
		for(Associate associate:associatelinkedlist)
			System.out.println(associate);
		
		System.out.println("Vector Implementation");
		Vector<String > vector=new Vector<>();
		vector.add("Ashav");
		vector.add("Keshav");
		vector.add("Neelam");
		vector.add("Rafe");
		System.out.println(vector.contains("Ashav"));
		System.out.println(vector.contains("Neelam"));
		Collections.sort(vector);
		for(String Name:vector)
			System.out.println(Name);
		
		Vector<Associate>associatevector=new Vector<>();
		associatevector.add(new Associate(101,15000,"Ashav"));
		associatevector.add(new Associate(102,15698,"Keshav"));
		
		Associate associatevectortobesearch=new Associate(102,18796,"Neelam");
		System.out.println(associatevector.contains(associatevectortobesearch));
		
	}
}
