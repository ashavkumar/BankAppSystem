package com.cg.banking.main;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.ConnectionProvider;

public class MainClass {
	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Database Connected");
		else
			System.out.println("Some Problem");
			
		BankingServices bankingservice=new BankingServicesImpl();
		//long accountNo=bankingservice.openAccount("Royal", 3000);
		//System.out.println(accountNo);
		//bankingservice.depositAmount(202422517, 500);
		//bankingservice.withdrawAmount(202422517, 1000, 3498);
		 //bankingservice.fundTransfer(202422517,202422518,1000,3406);
		//Account account=bankingservice.getAccountDetails(202422517);
		//System.out.println(account.toString());
		List<Account> accountList=new ArrayList<>();
		accountList=bankingservice.getAllAccountDetails();
		for(Account acc:accountList)
			System.out.println(acc.toString());
		List<Transaction>transactionList=new ArrayList<>();
		transactionList=bankingservice.getAccountAllTransaction(202422517);
		for(Transaction acc:transactionList)
			System.out.println(acc.toString());
		System.out.println(bankingservice.accountStatus(202422517));
	}
}
