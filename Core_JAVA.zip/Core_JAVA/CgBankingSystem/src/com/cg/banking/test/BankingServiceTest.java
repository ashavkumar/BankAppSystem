package com.cg.banking.test;

import org.junit.Before;
import org.junit.BeforeClass;

import com.cg.banking.services.BankingServicesImpl;

public class BankingServiceTest {
	private static BankingServices bankingServices; 
	@BeforeClass                      //method must be static
	public static void setUPTestEnv(){
		//System.out.println("setUPTestEnv()");
		bankingServices=new BankingServicesImpl();
	}
	@Before
	public  void setUpMockDataForTest(){
		//System.out.println("setUpMockDataForTest()");
	}
}
