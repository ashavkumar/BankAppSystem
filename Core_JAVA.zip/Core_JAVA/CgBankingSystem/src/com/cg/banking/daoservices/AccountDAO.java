package com.cg.banking.daoservices;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
public interface AccountDAO {
	Account save(Account account) throws SQLException,BankingServicesDownException;
	float findAccountNo(long accountNo) throws SQLException, BankingServicesDownException, AccountBlockedException;
	void depositUpdate(long accountNo, float amt) throws SQLException, BankingServicesDownException;
	void withdrawUpdate(long accountNo, float amt) throws SQLException, BankingServicesDownException;
	void validate(long accountNo, int pinNumber) throws BankingServicesDownException;
	Account getOne(long accountNo) throws BankingServicesDownException, AccountNotFoundException;
	ArrayList<Account> getAllAccount() throws BankingServicesDownException;
	List<Transaction> getAllTransaction(long accountNo) throws BankingServicesDownException, AccountNotFoundException;
	String statusGet(long accountNo) throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException;
}
