package com.cg.banking.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.util.ConnectionProvider;

public class AccountDAOImpl implements AccountDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	ArrayList<Account> accountList=new ArrayList<>();
	@Override
	public Account save(Account account)  throws SQLException, BankingServicesDownException{
		try{
			if(conn!=null){
				conn.setAutoCommit(false);
				PreparedStatement pstmt1=conn.prepareStatement("insert into Account(accountType,AccountBalance,pinNumber,status) values(?,?,?,?)");
				pstmt1.setString(1,account.getAccountType());
				pstmt1.setFloat(2, account.getAccountBalance());
				pstmt1.setInt(3, account.getPinNumber());
				pstmt1.setString(4, "Active");
				pstmt1.executeUpdate();

				PreparedStatement pstmt2=conn.prepareStatement("select Max(accountNo) from Account");
				ResultSet RS=pstmt2.executeQuery();
				RS.next();
				Long accountNo=RS.getLong(1);
				conn.commit();
				account.setAccountNo(accountNo);
			}
			else
				throw new BankingServicesDownException();
		}catch(SQLException e){
			conn.rollback();
			conn.close();
			e.printStackTrace();
		}
		finally{
			conn.setAutoCommit(true);		
		}
		return account;
	}
	@Override
	public float findAccountNo(long accountNo) throws SQLException, BankingServicesDownException, AccountBlockedException{
		if(conn==null)
			throw new BankingServicesDownException();
		PreparedStatement pstmt=conn.prepareStatement("select accountBalance,status from Account where accountNo="+accountNo);
		ResultSet RS=pstmt.executeQuery();
		if(RS.next()){
			float amt=RS.getFloat(1);
			String status=RS.getString(2);
			if(status.equals("Blocked"))
				throw new AccountBlockedException();
			return amt;
		}
		return -1;
	}
	@Override
	public void depositUpdate(long accountNo, float amt) throws SQLException, BankingServicesDownException {
		if(conn==null)
			throw new BankingServicesDownException();
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("update Account set AccountBalance="+amt+"where AccountNo="+accountNo);
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2=conn.prepareStatement("insert into Transaction(accountNo,amount,transactionType) values(?,?,?)");
			pstmt2.setLong(1, accountNo);
			pstmt2.setFloat(2, amt);
			pstmt2.setString(3, "Credit");
			pstmt2.executeUpdate();
			conn.commit();
		}catch(SQLException e){
			conn.rollback();
			conn.close();
			e.printStackTrace();
		}
		finally{
			conn.setAutoCommit(true);		
		}
	}
	@Override
	public void withdrawUpdate(long accountNo, float amt) throws SQLException, BankingServicesDownException {
		if(conn==null)
			throw new BankingServicesDownException();
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("update Account set AccountBalance="+amt+"where AccountNo="+accountNo);
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2=conn.prepareStatement("insert into Transaction(accountNo,amount,transactionType) values(?,?,?)");
			pstmt2.setLong(1, accountNo);
			pstmt2.setFloat(2, amt);
			pstmt2.setString(3, "Debit");
			pstmt2.executeUpdate();
			conn.commit();
		}catch(SQLException e){
			conn.rollback();
			conn.close();
			e.printStackTrace();
		}
		finally{
			conn.setAutoCommit(true);		
		}
	}
	@Override
	public void validate(long accountNo, int pinNumber) throws BankingServicesDownException {
		if(conn==null)
			throw new BankingServicesDownException();
		try{
			PreparedStatement pstmt=conn.prepareStatement("select pinNumber from Account where accountNo="+accountNo);
			ResultSet RS=pstmt.executeQuery();
			RS.next();
			int pinNo=RS.getInt(1);
			if(pinNo!=pinNumber)
				throw new InvalidPinNumberException();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Override
	public Account getOne(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
		if(conn==null)
			throw new BankingServicesDownException();
		try{
			PreparedStatement pstmt=conn.prepareStatement("select * from Account where accountNo="+accountNo);
			ResultSet RS=pstmt.executeQuery();
			if(RS.next()){
				long accountNumber=RS.getLong("accountNo");
				int pinNumber=RS.getInt("pinNumber");
				String status=RS.getString("status");
				float accountBalance=RS.getFloat("accountBalance");
				String accountType=RS.getString("accountType");
				
				Account account=new Account(pinNumber,accountType,status,accountBalance,accountNumber);
				return account;
				}else
				throw new AccountNotFoundException();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public ArrayList<Account>getAllAccount() throws BankingServicesDownException {
		if(conn==null)
			throw new BankingServicesDownException();
		try{
			PreparedStatement pstmt1=conn.prepareStatement("select * from Account ");
			ResultSet accountRS=pstmt1.executeQuery();
			while(accountRS.next()){
				int pinNumber=accountRS.getInt("pinNumber");
				String accountType=accountRS.getString("accountType");
				String status=accountRS.getString("status");
				float accountBalance=accountRS.getFloat("accountBalance");
				Long accountNumber=accountRS.getLong("accountNo");
				Account account=new Account(pinNumber,accountType,status,accountBalance,accountNumber);
				accountList.add(account);
			}
		}catch(SQLException e){
			e.printStackTrace();
			e.getMessage();
		}
		return accountList;
	}
	@Override
	public List<Transaction> getAllTransaction(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
		ArrayList<Transaction> listTransactions=new ArrayList<>();
		if(conn==null)
			throw new BankingServicesDownException();
		try{
			PreparedStatement pstmt1=conn.prepareStatement("select * from Transaction where accountNo="+accountNo);
			ResultSet transactionRS=pstmt1.executeQuery();
			while(transactionRS.next()){
				int transactionId=transactionRS.getInt("transactionId");
				String transactionType=transactionRS.getString("transactionType");
				long accountNumber=transactionRS.getLong("accountNo");
				float amount=transactionRS.getFloat("amount");
				Transaction transaction=new Transaction(transactionId,amount,accountNumber,transactionType);
				listTransactions.add(transaction);
			}
		}catch(SQLException e){
			e.printStackTrace();
			e.getMessage();
		}
		return listTransactions;
	}
	@Override
	public String statusGet(long accountNo) throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		if(conn==null)
			throw new BankingServicesDownException();
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement("select accountBalance,status from Account where accountNo="+accountNo);
			ResultSet RS=pstmt.executeQuery();
			if(RS.next()){
				if(RS.getFloat(1)==0)
					throw new AccountNotFoundException();
				if(RS.getString(2).equals("Blocked"))
					throw new AccountBlockedException();
				return RS.getString(2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
