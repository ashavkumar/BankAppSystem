package com.cg.banking.services;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	AccountDAO accountdao=new AccountDAOImpl();
	int min=1000;
	int max=9999;
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
		
		ArrayList<Account> accountList=new ArrayList<>();
		Account account=new Account(accountType,initBalance);
		if(initBalance<500)
			throw new InvalidAmountException();
		if(!accountType.startsWith("Saving") || !accountType.startsWith("Current"))
			throw new InvalidAccountTypeException();
		account.setPinNumber((int) ((Math.random()*((max-min)+1))+min));
		accountList.add(account);
		
		try {
			account=accountdao.save(account);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return account.getAccountNo();
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException {
		try{
			float amt=accountdao.findAccountNo(accountNo);
			if(amt==-1)
				throw new AccountNotFoundException();
			amt=amt+amount;
			accountdao.depositUpdate(accountNo,amt);
		}catch(SQLException e){
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		try{
			float amt=accountdao.findAccountNo(accountNo);
			if(amt==-1)
				throw new AccountNotFoundException();
			if(amount>amt)
				throw new InsufficientAmountException();
			accountdao.validate(accountNo,pinNumber);
			amt=amt-amount;
			accountdao.withdrawUpdate(accountNo,amt);
		}catch(SQLException e){
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		try{
			float amtTo=accountdao.findAccountNo(accountNoTo);
			if(amtTo==-1)
				throw new AccountNotFoundException();
			float amtFrom=accountdao.findAccountNo(accountNoFrom);
			if(amtFrom==-1)
				throw new AccountNotFoundException();
			if(amtFrom<transferAmount)
				throw new InsufficientAmountException();
			
			accountdao.validate(accountNoFrom,pinNumber);
			amtFrom=amtFrom-transferAmount;
			accountdao.withdrawUpdate(accountNoFrom,amtFrom);
			amtTo=amtTo+transferAmount;
			accountdao.depositUpdate(accountNoTo, amtTo);
		}catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException{
			Account account=accountdao.getOne(accountNo);
	return account;
	}

	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {
		List<Account> accountList=new ArrayList<>();
		accountList=accountdao.getAllAccount();
		return accountList;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transactionList=new ArrayList<>();
		transactionList=accountdao.getAllTransaction(accountNo);
		return transactionList;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,
			AccountBlockedException {
		String flag=accountdao.statusGet(accountNo);
		return flag;
	}
}
