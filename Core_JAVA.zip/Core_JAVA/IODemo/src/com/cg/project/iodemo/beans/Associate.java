package com.cg.project.iodemo.beans;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Associate implements Serializable{
	private int associateId;
	private int Salary;
	private String Name;
	Address address;
	public Associate() {
		super();
	}
	public Associate(int associateId, int salary, String name, Address address) {
		super();
		this.associateId = associateId;
		Salary = salary;
		Name = name;
		this.address = address;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", Salary=" + Salary
				+ ", Name=" + Name + ", address=" + address + "]";
	}
}
