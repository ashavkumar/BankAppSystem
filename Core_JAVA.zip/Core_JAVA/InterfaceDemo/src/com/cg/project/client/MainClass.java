package com.cg.project.client;

import com.cg.project.masterservices.MathServices;
import com.cg.project.masterservices.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) throws com.cg.project.exceptions.InvalidNumberRangeException {
		MathServices  services = new MathServicesImpl();
		System.out.println(services.multiNums(10,20));
		
		services.addNums(10, 20);
	}
}
