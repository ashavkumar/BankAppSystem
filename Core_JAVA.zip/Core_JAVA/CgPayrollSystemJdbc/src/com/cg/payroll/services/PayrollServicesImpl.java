package com.cg.payroll.services;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDaoImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associatedao =new AssociateDaoImpl();                    //to interact with DAO layer need to make object of AssociateDaoImpl into reference of AssociateDao interface
	private static final Logger logger=Logger.getLogger(PayrollServicesImpl.class);
	@Override
	public int accceptAssociateDetails( int yearlyInvestmentUnder8oC,String firstName, String lastName,
			String department, String designation, String pancard,
			String emailid, float basicSalary,
			float epf, float companypf, int accountNumber, String bankName,
			String ifscCode) throws PayrollServicesDownException{
		ArrayList<Associate>list=new ArrayList<>();
		Associate associate=new Associate(yearlyInvestmentUnder8oC ,firstName,lastName,department,designation,pancard,emailid,new BankDetails(accountNumber,bankName,ifscCode),new Salary(basicSalary,epf,companypf));
		list.add(associate);
		try {
			associate=associatedao.save(associate);                                    // to save the data into database need to go into DAO Layer with object containing all info
		} catch (SQLException e) {
			e.getMessage();
			logger.error(e.getMessage()+"= "+e.getCause()+"= "+e.getErrorCode()+"= ");
			e.printStackTrace();
		}
		return associate.getAssociateID();
	}
	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate = null;
		try {
			associate = associatedao.findOne(associateId);                  //check particular associateId exist or Not in Database
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");	
		float basicSalary=associate.getSalary().getBasicSalary();    //Tax Calculation Part Start Now
		float hra=50*basicSalary/100;
		associate.getSalary().setHra(hra);


		float conveyneceAllowance=25*basicSalary/100;
		associate.getSalary().setConveyneceAllowance(conveyneceAllowance);


		float otherAllowance=25*basicSalary/100;
		associate.getSalary().setOtherAllowance(otherAllowance);


		float personalAllowance=40*basicSalary/100;
		associate.getSalary().setPersonalAllownace(personalAllowance);


		float epf=12*basicSalary/100;
		associate.getSalary().setEpf(epf);

		float companyPf = 12*basicSalary/100;
		associate.getSalary().setCompanypf(companyPf);

		float gratuity=481*basicSalary/10000;
		associate.getSalary().setGratuity(gratuity);

		float grossSalary=basicSalary+conveyneceAllowance+otherAllowance+personalAllowance+epf;
		associate.getSalary().setGrossSalary(grossSalary);


		float yearlyInvestmentUnder80C = epf+associate.getYearlyInvestmentUnder8oC();
		if(yearlyInvestmentUnder80C>150000)
			yearlyInvestmentUnder80C=150000;
		associate.setYearlyInvestmentUnder8oC((int) yearlyInvestmentUnder80C);

		float taxableIncome = 12*(grossSalary-epf)-yearlyInvestmentUnder80C;
		float yearlyTax=0;
		if(taxableIncome<=250000)
			yearlyTax=0;
		else if(taxableIncome>250000 && taxableIncome<=500000)
			yearlyTax=5*(taxableIncome-250000)/100;
		else if(taxableIncome>500000 && taxableIncome<=1000000)
			yearlyTax=12500+20*(taxableIncome-500000);
		else
			yearlyTax=112500+30*(taxableIncome-1000000);
		float monthlyTax=yearlyTax/12;
		associate.getSalary().setMonthlyTax(monthlyTax);


		int netSalary=(int) (grossSalary-epf-monthlyTax);
		associate.getSalary().setNetsalary(netSalary);
		try {
			associatedao.update(associate);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return netSalary;
	}
	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException {
		Associate associate = null;
		try {
			associate = associatedao.findOne(associateId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		return associate;
	}
	@Override
	public ArrayList<Associate> getAllAssociatesDetails() {
		try {
			return associatedao.findAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
