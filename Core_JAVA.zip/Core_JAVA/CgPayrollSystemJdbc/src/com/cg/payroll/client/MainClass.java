package com.cg.payroll.client;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws PayrollServicesDownException,AssociateDetailsNotFoundException{
		Scanner scr=new Scanner(System.in);
		PayrollServices payrollServices = new PayrollServicesImpl();
		/*int associateID=payrollServices.accceptAssociateDetails(20000,"Ashav", "Kumar","YTP", "Sr.Analyst","HHTPK0434B","ashav.kr@gmail.com",  17300, 450, 850, 5336355, "SBI", "SBIN0001882");
		payrollServices.calculateNetSalary(associateID);
		Associate associate = payrollServices.getAssociateDetails(associateID);
		System.out.println(associate.toString());*/
		String ch=null;
		do{
			System.out.println("1.Enter Your Details");
			System.out.println("2.Calculate Your Net Salary");
			System.out.println("3.Get Your All Details");
			System.out.println("Enter Your Choice");
			int choice=scr.nextInt();
			switch(choice){
			case 1:
				System.out.println("Enter your Investment Amount in Rupees");
				int yearlyInvestmentUnder8oC=scr.nextInt();
				System.out.println("Enter your First Name");
				String firstName=scr.next();
				System.out.println("Enter your Last Name");
				String lastName=scr.next();
				System.out.println("Enter your Department");
				String department=scr.next();
				System.out.println("Enter your Designation");
				String designation=scr.next();
				System.out.println("Enter your pancard Number");
				String pancard=scr.next();
				System.out.println("Enter your Emial");
				String email=scr.next();
				System.out.println("Enter your basic Salary");
				float basicSalary=scr.nextFloat();
				System.out.println("Enter your epf");
				float epf=scr.nextFloat();
				System.out.println("Enter your companypf");
				float companypf=scr.nextFloat();
				System.out.println("Enter your AccountNumber");
				int accountNumber=scr.nextInt();
				System.out.println("Enter your BankName");
				String bankName=scr.next();
				System.out.println("Enter your ifsccode");
				String ifsccode=scr.next();
				int associateID=payrollServices.accceptAssociateDetails(yearlyInvestmentUnder8oC,firstName, lastName,department,designation,pancard,email,basicSalary, epf,companypf,accountNumber,bankName,ifsccode);
				if(associateID>0)
					System.out.println("Successfully Updated");
				else
					System.out.println("Not Updated");
				break;
			case 2:
				System.out.println("Enter your Associate Id");
				int associateID2=scr.nextInt();
				payrollServices.calculateNetSalary(associateID2);
				Associate associate2 = payrollServices.getAssociateDetails(associateID2);
				System.out.println(associate2.toString());
				break;
			case 3:
				System.out.println("Enter your Associate Id");
				int associateID3=scr.nextInt();
				Associate associate3 = payrollServices.getAssociateDetails(associateID3);
				System.out.println(associate3.toString());
				break;
			default:
				System.out.println("Enter Valid choice");
			}
			System.out.println("Do you want to continue then press y otherwise n");
			ch=scr.next();
		}while(ch.startsWith("y") || ch.startsWith("Y"));
	}
}
