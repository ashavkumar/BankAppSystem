package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.util.ConnectionProvider;
public class AssociateDaoImpl implements AssociateDAO {
	private Connection conn=ConnectionProvider.getDBConnection();    //Make connection with Database
	private static final Logger logger=Logger.getLogger(AssociateDaoImpl.class);
	@Override
	public Associate save(Associate associate) throws SQLException{
		try {
			conn.setAutoCommit(false);                                                                                //Set auto commit false on Database
			//query to insert associate object data into Database table
			PreparedStatement pstmt1=conn.prepareStatement("insert into Associate(yearlyInvestmentUnder8oC,firstName,lastName,department,designation,pancard,emailid) values(?,?,?,?,?,?,?)");
			pstmt1.setInt(1,associate.getYearlyInvestmentUnder8oC());
			pstmt1.setString(2,associate.getFirstName());
			pstmt1.setString(3,associate.getLastName());
			pstmt1.setString(4,associate.getDepartment());
			pstmt1.setString(5,associate.getDesignation());
			pstmt1.setString(6,associate.getPancard());
			pstmt1.setString(7,associate.getEmailid());
			pstmt1.executeUpdate();

			PreparedStatement pstmt2=conn.prepareStatement("select max(associateId) from Associate");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int associateId=rs.getInt(1);

			PreparedStatement pstmt3=conn.prepareStatement("insert into BankDetails values(?,?,?,?)");
			pstmt3.setInt(1,associateId);               //Change  from associateId to associate.getAssociateID()
			pstmt3.setLong(2,associate.getBankdetails().getAccountNumber());
			pstmt3.setString(3,associate.getBankdetails().getBankName());
			pstmt3.setString(4,associate.getBankdetails().getIfscCode());
			pstmt3.executeUpdate();

			PreparedStatement pstmt4=conn.prepareStatement("insert into Salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt4.setInt(1, associateId);        //Change  from associateId to associate.getAssociateID()
			pstmt4.setDouble(2, associate.getSalary().getBasicSalary());
			pstmt4.setDouble(3, associate.getSalary().getEpf());
			pstmt4.setDouble(4,associate.getSalary().getCompanypf());
			pstmt4.executeUpdate();

			conn.commit();
			associate.setAssociateID(associateId);   //Change  from associateId to associate.getAssociateID()
			return associate;
		}catch(SQLException e){
			e.printStackTrace();
			conn.rollback();                              
			throw e;
		}
		finally{
			conn.setAutoCommit(true);   //set auto commit true
		}
	}
	@Override
	public Associate findOne(int associateId) throws SQLException{
		PreparedStatement pstmt1=conn.prepareStatement("select * from Associate where associateId="+associateId);
		ResultSet associateRs=pstmt1.executeQuery();
		if(associateRs.next()){
			String firstName=associateRs.getString("firstName");
			String lastName=associateRs.getString("lastName");
			String department=associateRs.getString("department");
			String designation=associateRs.getString("designation");
			String pancard=associateRs.getString("pancard");
			String emailId=associateRs.getString("emailid");
			int yearlyInvestmentunder8oC=associateRs.getInt("yearlyInvestmentUnder8oc");
			Associate associate =new Associate(associateId,yearlyInvestmentunder8oC,firstName,lastName,department,designation,pancard,emailId);

			PreparedStatement pstmt2=conn.prepareStatement("select * from BankDetails where associateId="+associateId);
			ResultSet bankDetailsRs=pstmt2.executeQuery();
			bankDetailsRs.next();
			int accountNumber=bankDetailsRs.getInt("accountNumber");
			String bankName=bankDetailsRs.getString("bankName");
			String ifscCode=bankDetailsRs.getString("ifscCode");
			associate.setBankdetails(new BankDetails(accountNumber,bankName,ifscCode));


			PreparedStatement pstmt3=conn.prepareStatement("select * from Salary where associateId="+associateId);
			ResultSet salaryRs=pstmt3.executeQuery();
			salaryRs.next();
			float basicSalary=salaryRs.getFloat("basicSalary");
			float companypf=salaryRs.getFloat("companypf");
			float conveyneceAllowance=salaryRs.getFloat("conveyneceAllowance");
			float epf=salaryRs.getFloat("epf");
			float gratuity=salaryRs.getFloat("gratuity");
			float grossSalary=salaryRs.getFloat("grossSalary");
			float hra=salaryRs.getFloat("hra");
			float monthlyTax=salaryRs.getFloat("monthlyTax");
			float netSalary=salaryRs.getFloat("netsalary");
			float otherAllowance=salaryRs.getFloat("otherAllowance");
			float personalAllowance=salaryRs.getFloat("personalAllownace");
			associate.setSalary(new Salary(basicSalary,companypf,conveyneceAllowance,epf,gratuity,grossSalary,hra,monthlyTax,netSalary,otherAllowance,personalAllowance));
			return associate;
		}
		return null;
	}

	@Override
	public ArrayList<Associate> findAll() throws SQLException{
		try{
			PreparedStatement pstmt1=conn.prepareStatement("select * from Associate ");
			ResultSet associateRS=pstmt1.executeQuery();
			ArrayList<Associate> associates=new ArrayList<>();
			if(associateRS.next()){
				int associateId=associateRS.getInt("associateId");
				String firstName=associateRS.getString("firstName");
				String lastName=associateRS.getString("lastName");
				String department=associateRS.getString("department");
				String designation=associateRS.getString("designation");
				int yearlyInvestmentunder8oC=associateRS.getInt("yearlyInvestmentUnder8oc");
				String pancard=associateRS.getString("pancard");
				String emialId=associateRS.getString("emailid");
				Associate associate =new Associate(associateId,yearlyInvestmentunder8oC,firstName,lastName,department,designation,pancard,emialId,null,null);

				PreparedStatement pstmt2=conn.prepareStatement("select * from BankDetails where associateId="+associateId);
				ResultSet bankdetailsRS=pstmt2.executeQuery();
				bankdetailsRS.next();
				int accountNumber=bankdetailsRS.getInt("accountNumber");
				String bankName=bankdetailsRS.getString("bankName");
				String ifscCode=bankdetailsRS.getString("ifscCode");
				associate.setBankdetails(new BankDetails(accountNumber,bankName,ifscCode));

				PreparedStatement pstmt3=conn.prepareStatement("select * from Salary where associateId="+associateId);
				ResultSet salaryRS=pstmt3.executeQuery();
				salaryRS.next();
				float basicSalary=salaryRS.getFloat("basicSalary");
				float companypf=salaryRS.getFloat("companypf");
				float conveyneceAllowance=salaryRS.getFloat("conveyneceAllowance");
				float epf=salaryRS.getFloat("epf");
				float gratuity=salaryRS.getFloat("gratuity");
				float grossSalary=salaryRS.getFloat("grossSalary");
				float hra=salaryRS.getFloat("hra");
				float monthlyTax=salaryRS.getFloat("monthlyTax");
				float netSalary=salaryRS.getFloat("netsalary");
				float otherAllowance=salaryRS.getFloat("otherAllowance");
				float personalAllownace=salaryRS.getFloat("personalAllownace");
				associate.setSalary(new Salary(basicSalary,hra,conveyneceAllowance,otherAllowance,personalAllownace,monthlyTax,epf,companypf,gratuity,grossSalary,netSalary));
				associates.add(associate);
				return associates;
			}
		}catch(SQLException e){
			e.printStackTrace();
			e.getMessage();
			logger.error(e.getMessage()+"= "+e.getCause()+"= "+e.getErrorCode()+"= ");
		}
		return null;
	}
	@Override
	public void update(Associate associate) throws SQLException {
		
		PreparedStatement pstmt1=conn.prepareStatement("update Salary set hra = "+ associate.getSalary().getHra()+" ,ConveyneceAllowance  = "+associate.getSalary().getConveyneceAllowance() +", PersonalAllownace= "+associate.getSalary().getPersonalAllownace()+",OtherAllowance="+ associate.getSalary().getOtherAllowance()+",MonthlyTax="+associate.getSalary().getMonthlyTax()+" ,Gratuity="+associate.getSalary().getGratuity()+",GrossSalary="+associate.getSalary().getGrossSalary()+",Netsalary="+associate.getSalary().getNetsalary()+"where associateId="+associate.getAssociateID());
		try{
			pstmt1.executeUpdate();
			conn.commit();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
}
