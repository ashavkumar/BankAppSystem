package com.zensar.project.lambdainterface;
@FunctionalInterface
public interface FunctionalInterface2 {
public int add(int a,int b);
}
