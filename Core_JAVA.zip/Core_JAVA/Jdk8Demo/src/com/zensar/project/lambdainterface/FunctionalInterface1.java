package com.zensar.project.lambdainterface;
@FunctionalInterface
public interface FunctionalInterface1 {
	public String greetUser(String firstName,String lastName);
}
