package com.zensar.project.client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainClass2 {
	private static void method1() {
		Pattern pattern=Pattern.compile("H[abc]");
		Matcher matcher=pattern.matcher("Hello world How are You");
		while (matcher.find()) {
			System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}
	}
		private static void method2() {
			Pattern pattern=Pattern.compile("\\s");
			Matcher matcher=pattern.matcher("Hello world How are You");
			while (matcher.find()) {
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
			}
		}
		private static void method3() {
			Pattern pattern=Pattern.compile("\\d");
			Matcher matcher=pattern.matcher("Hello world How are You");
			while (matcher.find()) {
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
			}
		}
}
