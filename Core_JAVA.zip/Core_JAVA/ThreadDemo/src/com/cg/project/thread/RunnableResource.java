package com.cg.project.thread;
public class RunnableResource implements Runnable{

	@Override
	public void run() {
		Thread t=Thread.currentThread();
		if(t.getName().equals("abc"))
			for(int i=1;i<=10;i++)
				System.out.println("*="+i);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(t.getName().equals("pqr"))
			for(int i=1;i<=10;i++)
				System.out.println("@="+i);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
