package com.cg.project.thread;
public class MyThread extends Thread{
	public MyThread(String name) {
		super(name);
	}
	@Override
	public void run() {
		System.out.println(this.getName()+" thread print "+this.getName()+" Number");
		if(this.getName().equals("Even"))
			for(int i=1;i<=10;i++)
				if(i%2==0)
					System.out.println(i);
		if(this.getName().equals("Odd"))
			for(int i=1;i<=10;i++)
				if(i%2!=0)
					System.out.println(i);
	}

}
