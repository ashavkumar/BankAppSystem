package com.cg.project.thread;

import java.util.ArrayList;
import java.util.Collections;

import com.cg.project.bean.Employee;

public class MyThreadMainClass {
	public static void main(String[] args) {
		/*MyThread mythread1=new MyThread("Even");
		MyThread mythread2=new MyThread("Odd");
		mythread1.start();
		mythread2.start();*/
		
		RunnableResource r1=new RunnableResource();
		Thread t1=new Thread(r1,"abc");
		
		t1.start();
		try {
			t1.join(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Thread t2=new Thread(r1,"pqr");
		t2.start();
		
		Runnable runnableResources=()->{
			for(int i=1;i<10;i++)
				System.out.println("Tick "+i);
		};
		Thread th1=new Thread(runnableResources);
		th1.start();
		
		ArrayList<Employee> empList=new ArrayList<Employee>();
		empList.add(new Employee(111,11200,"Nilesh"));
		empList.add(new Employee(112,12000,"Kumar"));
		empList.add(new Employee(113,14500,"Ashav"));
		empList.add(new Employee(114,12500,"Neelam"));
		empList.add(new Employee(115,20000,"Rakesh"));
		empList.add(new Employee(116,14530,"Mahesh"));
		empList.add(new Employee(117,15550,"Rajesh"));
		
		Collections.sort(empList, (emp1,emp2)->emp1.getEmployeeId()-emp2.getEmployeeId());
		
		empList.stream()
		.distinct()
		.filter(e->e.getName().startsWith("N"))
		.forEach(employee->System.out.println(employee));
		
		long count=empList.stream()
				.distinct()
				.count();
				System.out.println(count+" "+empList.size());
				System.out.println(empList.stream().map(employee->employee.getSalary()));
	}
}
