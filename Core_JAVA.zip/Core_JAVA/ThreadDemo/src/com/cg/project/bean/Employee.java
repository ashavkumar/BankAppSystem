package com.cg.project.bean;
public class Employee {
	private int employeeId;
	private int salary;
	private String name;
	public Employee() {
		super();
	}
	public Employee(int employeeId, int salary, String name) {
		super();
		this.employeeId = employeeId;
		this.salary = salary;
		this.name = name;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	};
}
