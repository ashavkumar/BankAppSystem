package com.cg.project.main;
public class MainClass2 {
	public static void main(String[] args) {
	MainClass2 mclass1=new MainClass2();
	MainClass2 mclass2=new MainClass2();
	if(!mclass1.equals(mclass2))
		System.out.println("They are not Equal");
	if(mclass1 instanceof Object)
		System.out.println("mclass1 is an object");

	}

}
