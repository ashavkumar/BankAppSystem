package com.cg.project.inheritance;
public final class CEmployee extends Employee{
	private int noOfHrs,variablePay;
	public CEmployee() {
		super();
	}
	public CEmployee(int employeeId, String firstName, String lastName,
			int noOfHrs) {
		super(employeeId, firstName, lastName);
		this.noOfHrs=noOfHrs;
	}
	public int getNoOfHrs() {
		return noOfHrs;
	}
	public void setNoOfHrs(int noOfHrs) {
		this.noOfHrs = noOfHrs;
	}
	public int getVariablePay() {
		return variablePay;
	}
	/*public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}*/
	public void signContract(){
		System.out.println("Contract has been signed");
	}
	@Override
	public void calculateTotalSalary() {
		variablePay=noOfHrs*2000;
		this.setTotalSalary(variablePay);
	}
	@Override
	public String toString() {
		return super.toString()+",noOfHrs=" + noOfHrs + ", variablePay="+variablePay;
	}	
}
