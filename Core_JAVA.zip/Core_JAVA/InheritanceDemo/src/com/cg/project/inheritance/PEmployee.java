package com.cg.project.inheritance;
public class PEmployee extends Employee{
	private int hra,ta,da;
	public PEmployee() {
		super();
	}
	public PEmployee(int employeeId, String firstName, String lastName,
			int basicSalary) {
		super(employeeId, firstName, lastName, basicSalary);
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getTa() {
		return ta;
	}
	public void setTa(int ta) {
		this.ta = ta;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	@Override
	public void calculateTotalSalary() {
			hra=(this.getBasicSalary()*10)/100;
			da=(this.getBasicSalary()*10)/100;
			ta=(this.getBasicSalary()*10)/100;
			this.setTotalSalary(this.getBasicSalary()+hra+ta+da);	
		//super.calculateTotalSalary();
	}
	public String  toString() {
		return super.toString()+" hra=" + hra +",ta=" + ta +",da=" + da ;
	}
}
