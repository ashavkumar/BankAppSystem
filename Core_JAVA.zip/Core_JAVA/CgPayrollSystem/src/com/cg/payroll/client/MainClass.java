package com.cg.payroll.client;


import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

//import com.cg.payroll.beans.Associate;
//import com.cg.payroll.beans.BankDetails;
//import com.cg.payroll.beans.Salary;
public class MainClass {
	public static void main(String[] args) throws PayrollServicesDownException,AssociateDetailsNotFoundException{
		PayrollServices payrollServices = new PayrollServicesImpl(null);
		int associateID=payrollServices.accceptAssociateDetails(20000,"Ashav", "Kumar", "ashav.kumar@gmail.com", "YTP", "Sr.Analyst", "HHTPK0434B",  17300, 0, 0, 5336355, "SBI", "SBIN0001882");
		//System.out.println(associateID);
		Associate associate = payrollServices.getAssociateDetails(associateID);
		payrollServices.calculateNetSalary(associateID);
		//System.out.println(associate.toString());
		
		
		//ArrayList<Associate> associatearraylist =new ArrayList<>();
		//associatearraylist.add(new Associate(20000,"Ashav", "Kumar", "ashav.kumar@gmail.com", "YTP", "Sr.Analyst", "HHTPK0434B",  new BankDetails(5336355, "SBI", "SBIN0001882"), new Salary(17300, 0, 0) ));
		//int associateID=payrollServices.accceptAssociateDetails(20000,"Ashav", "Kumar", "ashav.kumar@gmail.com", "YTP", "Sr.Analyst", "HHTPK0434B",17300, 0, 0,5336355, "SBI", "SBIN0001882");
		 //Associate associate=payrollServices.getAssociateDetails(associateID);
		 //System.out.println(associateID);
		//payrollServices.calculateNetSalary(associateID);
		//for(Associate associate2:associatearraylist)
			//System.out.println(associate2);
		
		/*float basicSalary,hra,otherallowance,conveyenceallowance,grossSalary;
		Associate associate1= new Associate(101,15000,"Satish","Mahajan","Sr.con","YTP","JDDU2664","satish@gmail.com",new BankDetails(202422515,"SBI","SBI0001882") ,new Salary(17000,100,120,150,160,170,180,1900,900,2300,220));
		basicSalary=(associate1.getSalary()).getBasicSalary();
		hra=30*(associate1.getSalary()).getBasicSalary()/100;
		otherallowance=20*(associate1.getSalary()).getBasicSalary()/100;
		conveyenceallowance=20*(associate1.getSalary()).getBasicSalary()/100;
		 grossSalary=basicSalary+hra+otherallowance+conveyenceallowance;
		System.out.println(grossSalary);
		*/
		/*Associate.setASSOCIATE_COUNTER(101);
		System.out.println(Associate.getASSOCIATE_COUNTER());
		Associate associate1= new Associate(101,15000,"Satish","Mahajan","Sr.con","YTP","JDDU2664","satish@gmail.com");
		Associate associate2= new Associate(102,15000,"Rajesh","Kumar","Sr.con","YTP","UDIDI1737","rajesh@gmail.com");
		Associate associate3= new Associate(103,25000,"Keshav","Agrawal","Sr.Analyst","YTP","BZIZI1221","keshav@gmail.com");
		System.out.println("Associate Full Name: "+associate1.getFirstName()+" "+associate1.getLastName());
		System.out.println("Associate Full Name: "+associate2.getFirstName()+" "+associate2.getLastName());
		System.out.println("Associate Full Name: "+associate3.getFirstName()+" "+associate3.getLastName());
		BankDetails bankdetails1= new BankDetails(2024225152,"SBI","SBIN0001882");
		BankDetails bankdetails2= new BankDetails(2023223181,"ICICI","ICICI1990");
		BankDetails bankdetails3= new BankDetails(1078269564,"HDFC","HDFC8223");
		System.out.println("Account Number: "+bankdetails1.getAccountNumber()+"  Bank Name: "+bankdetails1.getBankName()+" IFSC Code: "+bankdetails1.getIfscCode());
		System.out.println("Account Number: "+bankdetails2.getAccountNumber()+"  Bank Name: "+bankdetails2.getBankName()+" IFSC Code: "+bankdetails2.getIfscCode());
		System.out.println("Account Number: "+bankdetails3.getAccountNumber()+"  Bank Name: "+bankdetails3.getBankName()+" IFSC Code: "+bankdetails3.getIfscCode());
		Salary salary1=new Salary(18000,100,120,150,160,170,180,1900,900,2300,220);
		Salary salary2=new Salary(19000,1002,180,155,100,170,180,1900,900,2300,220);
		Salary salary3=new Salary(22000,105,121,150,160,170,180,1900,900,2400,220);
		System.out.println("Basic Salary:"+salary1.getBasicSalary());
		System.out.println("Basic Salary:"+salary2.getBasicSalary());
		System.out.println("Basic Salary:"+salary3.getBasicSalary());*/
	
	}
}
