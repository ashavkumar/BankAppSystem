package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.payroll.beans.Associate;

public class AssociateDaoImpl implements AssociateDAO {
	private static  Associate []  associates = new Associate[10];
	private static int ASSOCIATE_IDX=0;
	private static int ASSOCIATE_ID_COUNTER=101;
	HashMap<Integer,Associate> map=new HashMap<Integer,Associate>();
	@Override
	public Associate save(Associate associate) {
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		map.put(ASSOCIATE_ID_COUNTER++, associate);
		//associates[ASSOCIATE_IDX++]=associate;
		return associate;
	}

	@Override
	public Associate findOne(int associateId) {
		/*for(int i=0;i<associates.length;i++) 
			if(associates[i]!=null&& associateId==associates[i].getAssociateID())
				return associates[i];
		return null;*/
		Set set=map.entrySet();
		Iterator iterator =set.iterator();
		while(iterator.hasNext()){
			 Map.Entry mentry = (Map.Entry)iterator.next();
			 System.out.println(mentry.getKey());
			 System.out.println(mentry.getValue());
	         //if(mentry.getKey()!=null && associateId==(int)mentry.getKey() )
	        	 //return (Associate) mentry.getValue();
			 //System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
	         //System.out.println(mentry.getValue());
		}    
		return null;
	}

	@Override
	public ArrayList<Associate> findAll() {
		return null;
	}

}
