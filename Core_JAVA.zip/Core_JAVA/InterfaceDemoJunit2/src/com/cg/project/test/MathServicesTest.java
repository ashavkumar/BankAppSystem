package com.cg.project.test;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.masterservices.MathServices;
import com.cg.project.masterservices.MathServicesImpl;

public class MathServicesTest {

/*	@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	private static MathServices mathServices; 
	@BeforeClass                      //method must be static
	public static void setUPTestEnv(){
		//System.out.println("setUPTestEnv()");
		mathServices=new MathServicesImpl();
	}
	@Before
	public  void setUpMockDataForTest(){
		//System.out.println("setUpMockDataForTest()");
 
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForFirstNOInvalid() throws InvalidNumberRangeException{
	//System.out.println("");	
		mathServices.addNums(-100, 200);
 
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForSecondNOInvalid() throws InvalidNumberRangeException{
		//System.out.println("");
		mathServices.addNums(100, -200);
	}
 
	@Test()
	public void testAddNumbersForBothValidNOS() throws InvalidNumberRangeException{
		//System.out.println("");
		int expected=mathServices.addNums(100, 200);
		Assert.assertEquals(expected, 300);
 
	}
 
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubNumbersForFirstNOInvalid() throws InvalidNumberRangeException{
	//System.out.println("");	
		mathServices.addNums(-100, 200);
 
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubNumbersForSecondNOInvalid() throws InvalidNumberRangeException{
		//System.out.println("");
		mathServices.addNums(100, -200);
	}
 
	@Test()
	public void testSubNumbersForBothValidNOS() throws InvalidNumberRangeException{
		//System.out.println("");
		int expected=mathServices.subNums(100, 200);
		Assert.assertEquals(expected, -100);
 
	}
	@After
	public void tearDownMockDataForTest(){
 
	}
	@AfterClass
	public static void tearDownTestEnv(){
		//System.out.println("after class");
		mathServices=null;
	}
}

